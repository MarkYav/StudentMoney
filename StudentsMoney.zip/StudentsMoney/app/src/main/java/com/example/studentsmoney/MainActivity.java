package com.example.studentsmoney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.audiofx.EnvironmentalReverb;
import android.view.View;
import android.view.View.OnClickListener;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    Button lifeBtn, educationBtn, funBtn, settingsBtn;

    SharedPreferences sPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        lifeBtn = (Button) findViewById(R.id.lifeBtn);
        lifeBtn.setOnClickListener(this);

        educationBtn = (Button) findViewById(R.id.educationBtn);
        educationBtn.setOnClickListener(this);

        funBtn = (Button) findViewById(R.id.funBtn);
        funBtn.setOnClickListener(this);

        settingsBtn = (Button) findViewById(R.id.settingsBtn);
        settingsBtn.setOnClickListener(this);

        if (!checkIsUserDataSet()){
            Intent intent3 = new Intent(this, SettingsActivity.class);
            startActivity(intent3);
            //TODO проверить, что пользователь ввёл все данные

            sPref = getPreferences(MODE_PRIVATE);
            SharedPreferences.Editor ed = sPref.edit();
            ed.putString("IsUserDataSet", "yes");
            ed.commit();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.lifeBtn:
                Intent intent = new Intent(this, LifeActivity.class);
                startActivity(intent);
                break;
            case R.id.educationBtn:
                Intent intent1 = new Intent(this, EducationActivity.class);
                startActivity(intent1);
                break;
            case R.id.funBtn:
                Intent intent2 = new Intent(this, FunActivity.class);
                startActivity(intent2);
                break;
            case R.id.settingsBtn:
                Intent intent3 = new Intent(this, SettingsActivity.class);
                startActivity(intent3);
                break;
        }
    }

    boolean checkIsUserDataSet() {
        sPref = getPreferences(MODE_PRIVATE);
        String savedText = sPref.getString("IsUserDataSet","no");
        if (savedText == "yes")
            return true;
        else
            return false;
    }

}