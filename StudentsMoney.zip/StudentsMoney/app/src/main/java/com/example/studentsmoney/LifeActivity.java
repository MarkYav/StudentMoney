package com.example.studentsmoney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LifeActivity extends AppCompatActivity implements View.OnClickListener {

    Button backBtn, foodBtn, apartmentBtn, fareBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_life);
        getSupportActionBar().hide();

        backBtn = (Button) findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        foodBtn = (Button) findViewById(R.id.foodBtn);
        foodBtn.setOnClickListener(this);

        apartmentBtn = (Button) findViewById(R.id.apartmentBtn);
        apartmentBtn.setOnClickListener(this);

        fareBtn = (Button) findViewById(R.id.fareBtn);
        fareBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        //Intent intent = new Intent(this);
        switch (view.getId()) {
            case R.id.backBtn:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;
            case R.id.foodBtn:
                Intent intent1 = new Intent(this, FoodActivity.class);
                startActivity(intent1);
                break;
            case R.id.apartmentBtn:
                Intent intent2 = new Intent(this, ApartmentActivity.class);
                startActivity(intent2);
                break;
            case R.id.fareBtn:
                Intent intent3 = new Intent(this, FareActivity.class);
                startActivity(intent3);
                break;
        }
    }
}